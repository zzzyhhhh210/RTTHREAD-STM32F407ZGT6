#include <rtthread.h>
#include <rtdevice.h>

#define PWM_DEV_NAME        "pwm8"         /* PWM设备名称 */
#define PWM_DEV_CHANNEL     1              /* TIM8_CH1对应通道0 */

struct rt_device_pwm *pwm_dev;            /* PWM设备句柄 */

static int pwm_led_sample(int argc, char *argv[])
{
    rt_uint32_t period, pulse;

    /* 查找设备 */
    pwm_dev = (struct rt_device_pwm *)rt_device_find(PWM_DEV_NAME);
    if (pwm_dev == RT_NULL)
    {
        rt_kprintf("pwm sample run failed! can't find %s device!\n", PWM_DEV_NAME);
        return RT_ERROR;
    }

    /* period 周期 ns，pulse高电平时间 ns */
    period = 1000000;   /* 1kHz */
    pulse  = 10000000;    /* 100%占空比 */

    rt_pwm_set(pwm_dev, PWM_DEV_CHANNEL, period, pulse);
    rt_pwm_enable(pwm_dev, PWM_DEV_CHANNEL);

    return RT_EOK;
}
MSH_CMD_EXPORT(pwm_led_sample, pwm sample);
