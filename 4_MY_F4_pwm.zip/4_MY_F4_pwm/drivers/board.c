/*
 * Copyright (c) 2006-2026, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-09-12     RealThread   first version
 */

#include <rtthread.h>
#include <board.h>
#include <drv_common.h>

#ifndef RT_WEAK
#define RT_WEAK rt_weak
#endif

RT_WEAK void rt_hw_board_init()
{
    extern void hw_board_init(char *clock_src, int32_t clock_src_freq, int32_t clock_target_freq);

    /* Heap initialization */
#if defined(RT_USING_HEAP)
    rt_system_heap_init((void *) HEAP_BEGIN, (void *) HEAP_END);
#endif

    hw_board_init(BSP_CLOCK_SOURCE, BSP_CLOCK_SOURCE_FREQ_MHZ, BSP_CLOCK_SYSTEM_FREQ_MHZ);

    /* Set the shell console output device */
#if defined(RT_USING_DEVICE) && defined(RT_USING_CONSOLE)
    rt_console_set_device(RT_CONSOLE_DEVICE_NAME);
#endif

    /* Board underlying hardware initialization */
#ifdef RT_USING_COMPONENTS_INIT
    rt_components_board_init();
#endif
    /* PWM */
    extern void RTT_STM32_HAL_PWM_Init(void);
    RTT_STM32_HAL_PWM_Init();

}

/**
* @brief TIM_Base MSP Initialization
* This function configures the hardware resources used in this example
* @param htim_base: TIM_Base handle pointer
* @retval None
*/
//void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef* htim_base)
//{
//  if(htim_base->Instance==TIM8)
//  {
//  /* USER CODE BEGIN TIM8_MspInit 0 */
//
//  /* USER CODE END TIM8_MspInit 0 */
//    /* Peripheral clock enable */
//    __HAL_RCC_TIM8_CLK_ENABLE();
//  /* USER CODE BEGIN TIM8_MspInit 1 */
//
//  /* USER CODE END TIM8_MspInit 1 */
//
//  }
//
//}
//
//void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim)
//{
//  GPIO_InitTypeDef GPIO_InitStruct = {0};
//  if(htim->Instance==TIM8)
//  {
//  /* USER CODE BEGIN TIM8_MspPostInit 0 */
//
//  /* USER CODE END TIM8_MspPostInit 0 */
//
//    __HAL_RCC_GPIOC_CLK_ENABLE();
//    /**TIM8 GPIO Configuration
//    PC6     ------> TIM8_CH1
//    */
//    GPIO_InitStruct.Pin = GPIO_PIN_6;
//    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//    GPIO_InitStruct.Alternate = GPIO_AF3_TIM8;
//    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
//
//  /* USER CODE BEGIN TIM8_MspPostInit 1 */
//
//  /* USER CODE END TIM8_MspPostInit 1 */
//  }
//
//}
