rt-thread/src/clock.o: ../rt-thread/src/clock.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rthw.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rthw.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h:
