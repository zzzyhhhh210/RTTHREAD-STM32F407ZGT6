rt-thread/components/drivers/misc/pin.o: \
 ../rt-thread/components/drivers/misc/pin.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\drivers\include/drivers/pin.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/msh_parse.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\drivers\include/drivers/pin.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/msh_parse.h:
