rt-thread/components/libc/compilers/common/cstdio.o: \
 ../rt-thread/components/libc/compilers/common/cstdio.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/stdio.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/stdio.h:
