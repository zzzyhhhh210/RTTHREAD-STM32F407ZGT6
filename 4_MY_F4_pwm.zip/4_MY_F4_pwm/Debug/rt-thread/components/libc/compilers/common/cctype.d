rt-thread/components/libc/compilers/common/cctype.o: \
 ../rt-thread/components/libc/compilers/common/cctype.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/ctype.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/ctype.h:
