rt-thread/components/libc/compilers/common/cwchar.o: \
 ../rt-thread/components/libc/compilers/common/cwchar.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/wchar.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/posix/wchar.h:
