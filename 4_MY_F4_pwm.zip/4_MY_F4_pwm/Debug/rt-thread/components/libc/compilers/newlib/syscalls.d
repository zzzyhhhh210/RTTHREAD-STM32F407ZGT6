rt-thread/components/libc/compilers/newlib/syscalls.o: \
 ../rt-thread/components/libc/compilers/newlib/syscalls.c \
 D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\newlib/fcntl.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/unistd.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/sys/unistd.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/compiler_private.h \
 D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdbg.h
D\:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\pwm/rtconfig.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\newlib/fcntl.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/unistd.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/sys/unistd.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include/compiler_private.h:
D\:\RT-ThreadStudio\workspace\pwm\rt-thread\include/rtdbg.h:
