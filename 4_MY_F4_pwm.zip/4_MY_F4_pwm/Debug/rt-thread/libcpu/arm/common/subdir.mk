################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../rt-thread/libcpu/arm/common/backtrace.c \
../rt-thread/libcpu/arm/common/div0.c \
../rt-thread/libcpu/arm/common/showmem.c 

OBJS += \
./rt-thread/libcpu/arm/common/backtrace.o \
./rt-thread/libcpu/arm/common/div0.o \
./rt-thread/libcpu/arm/common/showmem.o 

C_DEPS += \
./rt-thread/libcpu/arm/common/backtrace.d \
./rt-thread/libcpu/arm/common/div0.d \
./rt-thread/libcpu/arm/common/showmem.d 


# Each subdirectory must supply rules for building sources it contributes
rt-thread/libcpu/arm/common/%.o: ../rt-thread/libcpu/arm/common/%.c
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections -fdata-sections -Wall  -g -gdwarf-2 -DSOC_FAMILY_STM32 -DSOC_SERIES_STM32F4 -DUSE_HAL_DRIVER -DSTM32F407xx -I"D:\RT-ThreadStudio\workspace\pwm\drivers" -I"D:\RT-ThreadStudio\workspace\pwm\drivers\include" -I"D:\RT-ThreadStudio\workspace\pwm\drivers\include\config" -I"D:\RT-ThreadStudio\workspace\pwm\libraries\CMSIS\Device\ST\STM32F4xx\Include" -I"D:\RT-ThreadStudio\workspace\pwm\libraries\CMSIS\Include" -I"D:\RT-ThreadStudio\workspace\pwm\libraries\CMSIS\RTOS\Template" -I"D:\RT-ThreadStudio\workspace\pwm\libraries\STM32F4xx_HAL_Driver\Inc" -I"D:\RT-ThreadStudio\workspace\pwm\libraries\STM32F4xx_HAL_Driver\Inc\Legacy" -I"D:\RT-ThreadStudio\workspace\pwm" -I"D:\RT-ThreadStudio\workspace\pwm\applications" -I"D:\RT-ThreadStudio\workspace\pwm" -I"D:\RT-ThreadStudio\workspace\pwm\cubemx\Inc" -I"D:\RT-ThreadStudio\workspace\pwm\cubemx" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\drivers\include" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\finsh" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\common\include" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\compilers\newlib" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\posix\io\poll" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\posix\io\stdio" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\components\libc\posix\ipc" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\include" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\libcpu\arm\common" -I"D:\RT-ThreadStudio\workspace\pwm\rt-thread\libcpu\arm\cortex-m4" -include"D:\RT-ThreadStudio\workspace\pwm\rtconfig_preinc.h" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

