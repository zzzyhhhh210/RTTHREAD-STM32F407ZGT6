/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-09-13     Administrator       the first version
 */
#include <rtthread.h>
#include "lcd.h"

static int lcd_test(int argc, char **argv)
{
    lcd_boot_test();                                       /* 红/绿/蓝/白 + ID + size */
    lcd_show_string(20, 20, 200, 16, 16, "hello", RED);    /* 单独测文字 */
    return 0;
}
MSH_CMD_EXPORT(lcd_test, lcd boot test);
