#ifndef __LCD_H
#define __LCD_H
/* lcd.h - 16bit 8080 MCU TFTLCD driver on STM32F407 (CAR2 board).
 * Ported from ALIENTEK STM32F103 HAL example experiment-26.
 * Board wiring (custom F407ZGT6 / LQFP144):
 *   D0..D15 : PD14,PD15,PD0,PD1,PE7..PE15,PD8,PD9,PD10 (straight)
 *   WR=PD5(NWE)  RD=PD4(NOE)  CS=PG12(NE4)  RS=PF12(A6)
 *   RST=PG1 (active low)      BL=PD11 (high=on)            */
#include <stdint.h>
#ifndef USE_HAL_DRIVER
#define USE_HAL_DRIVER
#endif
#include "stm32f4xx_hal.h"

/* control pins */
#define LCD_WR_GPIO_PORT           GPIOD
#define LCD_WR_GPIO_PIN            GPIO_PIN_5
#define LCD_WR_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOD_CLK_ENABLE(); }while(0)
#define LCD_RD_GPIO_PORT           GPIOD
#define LCD_RD_GPIO_PIN            GPIO_PIN_4
#define LCD_RD_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOD_CLK_ENABLE(); }while(0)

//HYH版是PB0
#define LCD_BL_GPIO_PORT           GPIOB
#define LCD_BL_GPIO_PIN            GPIO_PIN_0
#define LCD_BL_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOD_CLK_ENABLE(); }while(0)

#define LCD_CS_GPIO_PORT           GPIOG
#define LCD_CS_GPIO_PIN            GPIO_PIN_12
#define LCD_CS_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOG_CLK_ENABLE(); }while(0)
#define LCD_RS_GPIO_PORT           GPIOF
#define LCD_RS_GPIO_PIN            GPIO_PIN_12
#define LCD_RS_GPIO_CLK_ENABLE()   do{ __HAL_RCC_GPIOF_CLK_ENABLE(); }while(0)

//HYH版是PG15
#define LCD_RST_GPIO_PORT          GPIOG
#define LCD_RST_GPIO_PIN           GPIO_PIN_15
#define LCD_RST_GPIO_CLK_ENABLE()  do{ __HAL_RCC_GPIOG_CLK_ENABLE(); }while(0)

/* FSMC bus parameters: CS=NE4(PG12), RS=A6(PF12).
 * Register/peripheral names on F407 stay "FSMC_*". HAL uses
 * unified "FMC_*" names. */
#define LCD_FSMC_NEX         4
#define LCD_FSMC_AX          6   //HYH版是10,修正如果 RS 接在 PF12 → 它只能当 FMC_A6 → AX 必须等于 6。
#define LCD_FSMC_BCRX        FSMC_Bank1->BTCR[(LCD_FSMC_NEX - 1) * 2]
#define LCD_FSMC_BTRX        FSMC_Bank1->BTCR[(LCD_FSMC_NEX - 1) * 2 + 1]
#define LCD_FSMC_BWTRX       FSMC_Bank1E->BWTR[(LCD_FSMC_NEX - 1) * 2]

typedef struct
{
    uint16_t width;
    uint16_t height;
    uint16_t id;
    uint8_t dir;
    uint16_t wramcmd;
    uint16_t setxcmd;
    uint16_t setycmd;
} _lcd_dev;

extern _lcd_dev lcddev;
extern uint32_t g_point_color;
extern uint32_t g_back_color;

#define LCD_BL(x)   do{ x ? HAL_GPIO_WritePin(LCD_BL_GPIO_PORT, LCD_BL_GPIO_PIN, GPIO_PIN_SET) : HAL_GPIO_WritePin(LCD_BL_GPIO_PORT, LCD_BL_GPIO_PIN, GPIO_PIN_RESET); }while(0)
#define LCD_RST(x)  do{ x ? HAL_GPIO_WritePin(LCD_RST_GPIO_PORT, LCD_RST_GPIO_PIN, GPIO_PIN_SET) : HAL_GPIO_WritePin(LCD_RST_GPIO_PORT, LCD_RST_GPIO_PIN, GPIO_PIN_RESET); }while(0)

typedef struct
{
    volatile uint16_t LCD_REG;
    volatile uint16_t LCD_RAM;
} LCD_TypeDef;

/* NE4 base 0x6C000000; A6 -> 2^6*2=0x80 minus 2.
 * LCD->LCD_REG=0x6C00007E, LCD->LCD_RAM=0x6C000080 */
#define LCD_BASE   ((uint32_t)((0x60000000 + (0x4000000 * (LCD_FSMC_NEX - 1))) | (((1 << LCD_FSMC_AX) * 2) - 2)))
#define LCD        ((LCD_TypeDef *)LCD_BASE)

#define L2R_U2D         0
#define L2R_D2U         1
#define R2L_U2D         2
#define R2L_D2U         3
#define U2D_L2R         4
#define U2D_R2L         5
#define D2U_L2R         6
#define D2U_R2L         7
#define DFT_SCAN_DIR    L2R_U2D

#define WHITE           0xFFFF
#define BLACK           0x0000
#define RED             0xF800
#define GREEN           0x07E0
#define BLUE            0x001F
#define MAGENTA         0xF81F
#define YELLOW          0xFFE0
#define CYAN            0x07FF
#define BROWN           0xBC40
#define BRRED           0xFC07
#define GRAY            0x8430
#define DARKBLUE        0x01CF
#define LIGHTBLUE       0x7D7C
#define GRAYBLUE        0x5458
#define LIGHTGREEN      0x841F
#define LGRAY           0xC618
#define LGRAYBLUE       0xA651
#define LBBLUE          0x2B12

/* SSD1963 7-inch panel params (used by lcd_ex.c) */
#define SSD_HOR_RESOLUTION      800
#define SSD_VER_RESOLUTION      480
#define SSD_HOR_PULSE_WIDTH     1
#define SSD_HOR_BACK_PORCH      46
#define SSD_HOR_FRONT_PORCH     210
#define SSD_VER_PULSE_WIDTH     1
#define SSD_VER_BACK_PORCH      23
#define SSD_VER_FRONT_PORCH     22
#define SSD_HT          (SSD_HOR_RESOLUTION + SSD_HOR_BACK_PORCH + SSD_HOR_FRONT_PORCH)
#define SSD_HPS         (SSD_HOR_BACK_PORCH)
#define SSD_VT          (SSD_VER_RESOLUTION + SSD_VER_BACK_PORCH + SSD_VER_FRONT_PORCH)
#define SSD_VPS         (SSD_VER_BACK_PORCH)

void lcd_wr_data(volatile uint16_t data);
void lcd_wr_regno(volatile uint16_t regno);
void lcd_write_reg(uint16_t regno, uint16_t data);
void lcd_init(void);
void lcd_display_on(void);
void lcd_display_off(void);
void lcd_scan_dir(uint8_t dir);
void lcd_display_dir(uint8_t dir);
void lcd_ssd_backlight_set(uint8_t pwm);
void lcd_write_ram_prepare(void);
void lcd_set_cursor(uint16_t x, uint16_t y);
uint32_t lcd_read_point(uint16_t x, uint16_t y);
void lcd_draw_point(uint16_t x, uint16_t y, uint32_t color);
void lcd_clear(uint16_t color);
void lcd_fill_circle(uint16_t x, uint16_t y, uint16_t r, uint16_t color);
void lcd_draw_circle(uint16_t x0, uint16_t y0, uint8_t r, uint16_t color);
void lcd_draw_hline(uint16_t x, uint16_t y, uint16_t len, uint16_t color);
void lcd_set_window(uint16_t sx, uint16_t sy, uint16_t width, uint16_t height);
void lcd_fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint32_t color);
void lcd_color_fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t *color);
void lcd_draw_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void lcd_draw_rectangle(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void lcd_show_char(uint16_t x, uint16_t y, char chr, uint8_t size, uint8_t mode, uint16_t color);
void lcd_show_num(uint16_t x, uint16_t y, uint32_t num, uint8_t len, uint8_t size, uint16_t color);
void lcd_show_xnum(uint16_t x, uint16_t y, uint32_t num, uint8_t len, uint8_t size, uint8_t mode, uint16_t color);
void lcd_show_string(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t size, char *p, uint16_t color);
/* busy-wait delays, no dependency on RTOS tick / HAL timebase */
void lcd_busy_delay_us(uint32_t us);
void lcd_busy_delay_ms(uint32_t ms);
#define delay_ms(x)     lcd_busy_delay_ms(x)
#define delay_us(x)     lcd_busy_delay_us(x)

/* panel register init sequences live in lcd_ex.c (separate TU) */
void lcd_ex_st7789_reginit(void);
void lcd_ex_ili9341_reginit(void);
void lcd_ex_nt35310_reginit(void);
void lcd_ex_st7796_reginit(void);
void lcd_ex_nt35510_reginit(void);
void lcd_ex_ili9806_reginit(void);
void lcd_ex_ssd1963_reginit(void);

void lcd_boot_test(void);

#endif
