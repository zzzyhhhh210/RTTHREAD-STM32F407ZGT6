/*
 * Copyright (c) 2006-2026, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-09-13     RT-Thread    first version
 */

#include <rtthread.h>
#include "lcd.h"

int main(void)
{
    lcd_boot_test();                                       /* 红/绿/蓝/白 + ID + size */
    lcd_show_string(20, 20, 200, 16, 16, "hello", RED);
    return 0;
}

