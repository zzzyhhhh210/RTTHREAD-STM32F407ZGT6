################################################################################
# 自动生成的文件。不要编辑！
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../applications/lcd.c \
../applications/lcd_ex.c \
../applications/lcdsample.c \
../applications/main.c 

OBJS += \
./applications/lcd.o \
./applications/lcd_ex.o \
./applications/lcdsample.o \
./applications/main.o 

C_DEPS += \
./applications/lcd.d \
./applications/lcd_ex.d \
./applications/lcdsample.d \
./applications/main.d 


# Each subdirectory must supply rules for building sources it contributes
applications/%.o: ../applications/%.c
	arm-none-eabi-gcc -mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -ffunction-sections -fdata-sections -Wall  -g -gdwarf-2 -DSOC_FAMILY_STM32 -DSOC_SERIES_STM32F4 -DUSE_HAL_DRIVER -DSTM32F407xx -I"D:\RT-ThreadStudio\workspace\PLLCD2\drivers" -I"D:\RT-ThreadStudio\workspace\PLLCD2\drivers\include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\drivers\include\config" -I"D:\RT-ThreadStudio\workspace\PLLCD2\libraries\CMSIS\Device\ST\STM32F4xx\Include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\libraries\CMSIS\Include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\libraries\CMSIS\RTOS\Template" -I"D:\RT-ThreadStudio\workspace\PLLCD2\libraries\STM32F4xx_HAL_Driver\Inc" -I"D:\RT-ThreadStudio\workspace\PLLCD2\libraries\STM32F4xx_HAL_Driver\Inc\Legacy" -I"D:\RT-ThreadStudio\workspace\PLLCD2" -I"D:\RT-ThreadStudio\workspace\PLLCD2\applications" -I"D:\RT-ThreadStudio\workspace\PLLCD2" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\drivers\include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\finsh" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\libc\compilers\common\include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\libc\compilers\newlib" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\libc\posix\io\poll" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\libc\posix\io\stdio" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\components\libc\posix\ipc" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\include" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\libcpu\arm\common" -I"D:\RT-ThreadStudio\workspace\PLLCD2\rt-thread\libcpu\arm\cortex-m4" -include"D:\RT-ThreadStudio\workspace\PLLCD2\rtconfig_preinc.h" -std=gnu11 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -c -o "$@" "$<"

