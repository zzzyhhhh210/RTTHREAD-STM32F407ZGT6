rt-thread/src/ipc.o: ../rt-thread/src/ipc.c \
 D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\pwmled/rtconfig.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\finsh/finsh.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rthw.h
D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\pwmled/rtconfig.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\finsh/finsh.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rthw.h:
