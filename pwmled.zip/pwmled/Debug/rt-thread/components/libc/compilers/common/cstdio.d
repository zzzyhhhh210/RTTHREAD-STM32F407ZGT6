rt-thread/components/libc/compilers/common/cstdio.o: \
 ../rt-thread/components/libc/compilers/common/cstdio.c \
 D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/stdio.h
D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/stdio.h:
