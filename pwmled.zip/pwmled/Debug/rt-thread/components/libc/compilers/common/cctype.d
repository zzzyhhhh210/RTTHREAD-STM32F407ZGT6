rt-thread/components/libc/compilers/common/cctype.o: \
 ../rt-thread/components/libc/compilers/common/cctype.c \
 D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/ctype.h
D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/ctype.h:
