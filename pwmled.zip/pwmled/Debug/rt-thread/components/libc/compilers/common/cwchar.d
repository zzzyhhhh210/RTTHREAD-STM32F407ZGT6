rt-thread/components/libc/compilers/common/cwchar.o: \
 ../rt-thread/components/libc/compilers/common/cwchar.c \
 D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/wchar.h
D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\libc\compilers\common\include/posix/wchar.h:
