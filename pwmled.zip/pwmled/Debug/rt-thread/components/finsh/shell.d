rt-thread/components/finsh/shell.o: ../rt-thread/components/finsh/shell.c \
 D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rthw.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtthread.h \
 D\:\RT-ThreadStudio\workspace\pwmled/rtconfig.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdebug.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdef.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtservice.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtm.h \
 D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\finsh/finsh.h \
 ../rt-thread/components/finsh/shell.h \
 ../rt-thread/components/finsh/finsh.h \
 ../rt-thread/components/finsh/msh.h
D\:\RT-ThreadStudio\workspace\pwmled\rtconfig_preinc.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rthw.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtthread.h:
D\:\RT-ThreadStudio\workspace\pwmled/rtconfig.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdebug.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtdef.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtservice.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\include/rtm.h:
D\:\RT-ThreadStudio\workspace\pwmled\rt-thread\components\finsh/finsh.h:
../rt-thread/components/finsh/shell.h:
../rt-thread/components/finsh/finsh.h:
../rt-thread/components/finsh/msh.h:
