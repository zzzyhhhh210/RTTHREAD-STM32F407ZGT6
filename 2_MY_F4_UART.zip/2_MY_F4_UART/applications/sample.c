/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-09-09     Administrator       the first version
 */
/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2026-09-09     Administrator       the first version
 */
#include <rtthread.h>
#include <rtdevice.h>
#include <board.h>

#define DBG_TAG "pin"
#define DBG_LVL         DBG_LOG
#include <rtdbg.h>

#define THREAD_PRIORITY         25      // 线程优先级
#define THREAD_STACK_SIZE       512     // 线程堆栈大小
#define THREAD_TIMESLICE        5       // 线程时间片

#define LED_BLUE_NUM        GET_PIN(F,  9)
#define KEY_DOWN_NUM        GET_PIN(E,  3)

void led_blue_turn(void *args)
{
    static char count=0;
    if (count%2==0) {
        rt_pin_write(LED_BLUE_NUM, PIN_LOW);LOG_D("led_blue_turn!\n");
    }
    else {
        rt_pin_write(LED_BLUE_NUM, PIN_HIGH);LOG_D("led_blue_off!\n");
    }

    count++;
}

/* 线程示例 */
int thread_pin(void)
{
    /*设置LED引脚为输出模式 */
//    rt_base_t LED_RED_NUM= rt_pin_get("PF.12");
    rt_pin_mode(LED_BLUE_NUM, PIN_MODE_OUTPUT);
    /*设置按键引脚为输入模式*/
    rt_pin_mode(KEY_DOWN_NUM, PIN_MODE_INPUT_PULLUP);

    /* 绑定中断，下降沿模式，回调函数名为led_blue_on */
    rt_pin_attach_irq(KEY_DOWN_NUM, PIN_IRQ_MODE_FALLING, led_blue_turn, RT_NULL);
    /* 使能中断 */
    rt_pin_irq_enable(KEY_DOWN_NUM, PIN_IRQ_ENABLE);

    return 0;
}

/* 导出到 msh 命令列表中 */
MSH_CMD_EXPORT(thread_pin, thread_pin);
